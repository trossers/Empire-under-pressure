# S.A.S.S.Y. — Counselor UI Kit

The intelligent, ironic AI advisor. Never a chatbot, never a wizard. S.A.S.S.Y. is a presence — a vellum scroll on the player's desk that occasionally clears its throat.

## Files
- `index.html` — full counsel surface: header, vellum dispatch, conversation thread, compose, aside cards, in-context summon panels.
- `sassy.css` — vellum, oxblood seal, italic Spectral.

## Voice rules
- Always italic Spectral. Never sans, never bold.
- Long sentences. Em-dashes. Asides. Polite undermining ("naturally", "I leave it to your better judgment").
- Never "you should". Always "I observe", "shall we", "may I". 
- Never warns in capitals. Never uses emoji or icons inside her own copy.

## Surfaces
1. **The vellum dispatch** — long-form: the morning brief, the unsolicited note. Carries the oxblood seal in the corner.
2. **The conversation thread** — alternating italic vellum (her) and serif parchment (sovereign).
3. **The summon panel** — floats in-context: above an unsealed edict, beside a tense diplomacy choice. Two variants: chrome-dark ("on edicts") and vellum-light ("on quiet matters").
4. **The aside card** — small, persistent counsel that lives in the right rail of major screens.

## Substitution flag
The seal motif uses an oxblood radial gradient with the letters "S.A./S.S.Y." in two lines. If you have a heraldic mark for the counselor, swap into `.sy-seal::before/after`.
