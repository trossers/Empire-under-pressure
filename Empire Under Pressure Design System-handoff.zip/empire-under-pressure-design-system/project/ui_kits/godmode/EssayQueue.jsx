/* eslint-disable */
const EssayQueue = () => {
  const essays = [
    { author:"Calidone · A. Mendez", title:"On the Mercy of Sovereigns", words:1842, status:"graded", grade:"A−", note:"Argues from Aquinas; engages Vorant case study." },
    { author:"Marivell · S. Patel", title:"Whether the Crown Owes Bread Before Law", words:2104, status:"graded", grade:"A", note:"Strongest essay this cycle. Cite in lecture VII." },
    { author:"Vorant · R. Okafor", title:"The Right of First Mobilization", words:1672, status:"pending", grade:"—", note:"Provocative thesis; verify Hobbes citation page 14." },
    { author:"Halberd · J. Lin", title:"The Counter-Mobilization", words:1490, status:"pending", grade:"—", note:"Direct response to Okafor — read in sequence." },
    { author:"Eldwyn · T. Iqbal", title:"Repute and the Long Cycle", words:1955, status:"pending", grade:"—", note:"" },
    { author:"Vesper · N. Achebe", title:"The Counsel One Should Distrust", words:1788, status:"pending", grade:"—", note:"Engages S.A.S.S.Y. as a philosophical object — interesting." },
    { author:"Ostvar · E. Larsen", title:"Treaty as Theatre", words:1612, status:"pending", grade:"—", note:"" },
    { author:"Strathvale · L. Park", title:"On the Cost of Stability", words:1721, status:"graded", grade:"B+", note:"Solid; thesis softens in §4." },
    { author:"Sornland · I. Martín", title:"Of Subsidies and Suspicion", words:1899, status:"pending", grade:"—", note:"" },
    { author:"Brynholm · C. Devlin", title:"Against the Doctrine of Stable Imperium", words:1544, status:"pending", grade:"—", note:"Heterodox; engage seriously." },
    { author:"Pelmark · Z. Reyes", title:"— not submitted —", words:0, status:"missing", grade:"—", note:"Past deadline 26h." },
    { author:"Aldemar · F. Rossi", title:"— not submitted —", words:0, status:"missing", grade:"—", note:"Past deadline 9h." },
  ];
  const pending = essays.filter(e=>e.status==="pending").length;
  const missing = essays.filter(e=>e.status==="missing").length;
  return (
    <div>
      <div className="gm-page-header">
        <div>
          <h1 className="gm-page-title">Essay Queue · Cycle XI</h1>
          <div className="gm-page-sub">Twelve manuscripts. Eight await your hand. Two unwritten.</div>
        </div>
        <div style={{display:"flex",gap:8}}>
          <GMBtn kind="ghost" icon="ph-funnel"><span>Pending only</span></GMBtn>
          <GMBtn kind="secondary" icon="ph-export"><span>Export Cycle</span></GMBtn>
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14,marginBottom:18}}>
        <GMStat label="Submitted" value="10 / 18" />
        <GMStat label="Pending Grade" value={pending} delta="oldest 11h" />
        <GMStat label="Past Deadline" value={missing} delta="−2 students" deltaTone="down"/>
        <GMStat label="Cycle Median Grade" value="B+" />
      </div>

      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:16}}>
        <GMCard chrome={{icon:"ph-feather", label:"Manuscripts"}}>
          {essays.map((e,i) => (
            <div className="gm-essay-row" key={i}>
              <div style={{width:36,height:36,borderRadius:2,background:"rgba(168,128,74,.1)",border:"1px solid rgba(168,128,74,.25)",display:"flex",alignItems:"center",justifyContent:"center",color:"var(--gold-2)"}}>
                <i className={"ph " + (e.status==="missing"?"ph-x":e.status==="graded"?"ph-check-circle":"ph-scroll")}></i>
              </div>
              <div>
                <div className="gm-essay-author">{e.author}</div>
                <div className="gm-essay-title">{e.title}</div>
                {e.note && <div style={{fontFamily:"var(--font-italic)",fontStyle:"italic",fontSize:12.5,color:"var(--parchment-3)",marginTop:3}}>{e.note}</div>}
              </div>
              <div className="gm-essay-meta">{e.words ? e.words.toLocaleString() + " words" : "—"}</div>
              <span className="gm-grade-pill" style={e.status==="missing"?{background:"rgba(122,31,35,.18)",color:"#e8a7a9",borderColor:"rgba(122,31,35,.4)"}:e.status==="graded"?{background:"rgba(74,92,58,.25)",color:"#b9c8a4",borderColor:"rgba(74,92,58,.45)"}:{background:"rgba(168,128,74,.12)"}}>{e.grade}</span>
              <GMBtn kind={e.status==="pending"?"primary":"ghost"} icon={e.status==="pending"?"ph-pen-nib":"ph-eye"}>
                <span>{e.status==="pending"?"Mark":e.status==="missing"?"Remind":"Review"}</span>
              </GMBtn>
            </div>
          ))}
        </GMCard>

        <GMCard chrome={{icon:"ph-pen-nib", label:"Grading Lane"}}>
          <div style={{fontFamily:"var(--font-display)",fontSize:11,letterSpacing:".18em",textTransform:"uppercase",color:"var(--parchment-3)"}}>Now reading</div>
          <div style={{fontFamily:"var(--font-display)",fontSize:14,letterSpacing:".1em",textTransform:"uppercase",color:"var(--gold-2)",marginTop:6}}>Vorant · R. Okafor</div>
          <div style={{fontFamily:"var(--font-serif)",fontSize:15,color:"var(--parchment-1)",marginTop:4,fontStyle:"italic"}}>The Right of First Mobilization</div>
          <div style={{height:1,background:"rgba(168,128,74,.25)",margin:"14px 0"}}></div>

          <div style={{fontFamily:"var(--font-italic)",fontStyle:"italic",fontSize:14,lineHeight:1.6,color:"var(--parchment-2)",marginBottom:14}}>
            "If a sovereign waits for the first blow, the sovereign is no longer sovereign — only respondent. The doctrine of legitimate first strike, properly construed…"
          </div>

          <div className="gm-balance-label" style={{marginBottom:6}}>Mark</div>
          <div style={{display:"flex",gap:6,marginBottom:14}}>
            {["A","A−","B+","B","B−","C+","C","D","F"].map(g => (
              <button key={g} className="gm-grade-pill" style={{cursor:"pointer",background:g==="A−"?"rgba(74,92,58,.35)":"rgba(168,128,74,.1)"}}>{g}</button>
            ))}
          </div>

          <div className="gm-balance-label" style={{marginBottom:6}}>Marginalia</div>
          <textarea rows={4} defaultValue={"Strong Hobbesian core, but the §3 elision of Grotius is convenient. Engage the asymmetry argument directly in revision."} style={{width:"100%",background:"#100706",color:"var(--parchment-1)",border:"1px solid rgba(168,128,74,.3)",padding:"10px 12px",fontFamily:"var(--font-italic)",fontStyle:"italic",fontSize:13.5,lineHeight:1.55,borderRadius:2,resize:"vertical"}}/>

          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:14}}>
            <label style={{fontFamily:"var(--font-serif)",fontSize:12.5,color:"var(--parchment-3)",fontStyle:"italic"}}><input type="checkbox"/> visible to other sovereigns</label>
            <div style={{display:"flex",gap:6}}>
              <GMBtn kind="ghost">Save Draft</GMBtn>
              <GMBtn kind="primary" icon="ph-stamp">Seal Mark</GMBtn>
            </div>
          </div>
        </GMCard>
      </div>
    </div>
  );
};
window.EssayQueue = EssayQueue;
