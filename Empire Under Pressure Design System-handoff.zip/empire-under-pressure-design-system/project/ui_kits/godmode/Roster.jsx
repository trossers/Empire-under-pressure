/* eslint-disable */
const Roster = () => {
  const enriched = KINGDOMS.map((k,i) => ({
    ...k,
    summons: [12,7,4,3,9,0,9,2,4,3,6,0,5,3,11,2,4,3][i] ?? 4,
    sessions: [42,28,33,38,31,40,12,29,35,22,36,44,30,33,8,37,27,34][i] ?? 30,
    edictsTotal: [29,18,21,33,16,35,9,24,28,17,26,38,22,27,4,30,19,28][i] ?? 24,
    repute: [+12,-4,-1,+18,-3,+9,-22,+7,+4,-2,+8,+15,-5,+3,-19,+6,-1,+5][i] ?? 0,
  }));

  return (
    <div>
      <div className="gm-page-header">
        <div>
          <h1 className="gm-page-title">Sovereign Roster</h1>
          <div className="gm-page-sub">Engagement, repute, and the standing of the eighteen.</div>
        </div>
        <div style={{display:"flex",gap:8}}>
          <input placeholder="Search sovereigns…" style={{background:"#100706",color:"var(--parchment-1)",border:"1px solid rgba(168,128,74,.3)",padding:"8px 12px",fontFamily:"var(--font-serif)",fontSize:13,borderRadius:2,width:240}}/>
          <GMBtn kind="ghost" icon="ph-arrows-down-up"><span>Sort: Engagement</span></GMBtn>
          <GMBtn kind="secondary" icon="ph-export"><span>Export</span></GMBtn>
        </div>
      </div>

      <GMCard chrome={{icon:"ph-users-three", label:"Eighteen Sovereigns"}} padded={false}>
        <table className="gm-roster">
          <thead>
            <tr>
              <th>Sovereign</th><th>Student</th><th>Stab.</th><th>Leg.</th><th>Trea.</th><th>Mil.</th>
              <th>Repute</th><th>Edicts</th><th>S.A.S.S.Y.</th><th>Sessions</th><th>State</th><th></th>
            </tr>
          </thead>
          <tbody>
            {enriched.map(k => (
              <tr key={k.name}>
                <td><span className="gm-roster-crest">{k.name[0]}</span><span style={{fontFamily:"var(--font-display)",fontSize:11.5,letterSpacing:".1em",textTransform:"uppercase",color:"var(--gold-2)"}}>{k.name}</span></td>
                <td style={{fontStyle:"italic"}}>{k.student}</td>
                <td className="num">{k.stab}</td>
                <td className="num">{k.leg}</td>
                <td className="num">{k.tre}</td>
                <td className="num">{k.mil}</td>
                <td className="num" style={{color:k.repute<0?"#d68389":k.repute>0?"#9bb18a":"var(--parchment-3)"}}>{k.repute>0?"+":""}{k.repute}</td>
                <td className="num">{k.edictsTotal}</td>
                <td className="num">{k.summons}</td>
                <td className="num">{k.sessions}</td>
                <td>
                  <span className={"gm-state-dot " + (k.state==="danger"?"danger":k.state==="warn"?"warn":"ok")}></span>
                  <span style={{fontFamily:"var(--font-display)",fontSize:10,letterSpacing:".18em",textTransform:"uppercase",color:k.state==="danger"?"#e8a7a9":k.state==="warn"?"#dbb877":"#9bb18a"}}>
                    {k.state==="danger"?"Crisis":k.state==="warn"?"Wavering":"Stable"}
                  </span>
                </td>
                <td><GMBtn kind="ghost" icon="ph-eye"><span>Open</span></GMBtn></td>
              </tr>
            ))}
          </tbody>
        </table>
      </GMCard>
    </div>
  );
};
window.Roster = Roster;
