/* eslint-disable */
const EventInjector = () => {
  const { useState } = React;
  const events = [
    { id:"famine", icon:"ph-bowl-food", name:"Famine in the Northern Reach", scope:"Regional · 4–6 kingdoms", impact:"Treasury -10, Stability -8 over 2 cycles", risk:"high" },
    { id:"plague", icon:"ph-syringe", name:"Pestilence on Trade Routes", scope:"Imperium-wide", impact:"Trade friction +0.4, Population -3%", risk:"high" },
    { id:"comet", icon:"ph-shooting-star", name:"Omen — the Bright Comet", scope:"Imperium-wide · ceremonial", impact:"Legitimacy ±6 by piety roll", risk:"low" },
    { id:"bandit", icon:"ph-mask-sad", name:"Brigand Lords Rising", scope:"3 kingdoms (chosen)", impact:"Militia required +12, Treasury -6", risk:"med" },
    { id:"emissary", icon:"ph-paper-plane-tilt", name:"Imperial Emissary Arrives", scope:"Single kingdom", impact:"Forces a diplomacy edict within 1 cycle", risk:"low" },
    { id:"heresy", icon:"ph-flame", name:"Theological Schism", scope:"Imperium-wide", impact:"Legitimacy -10 unless edict of accommodation issued", risk:"med" },
    { id:"discovery", icon:"ph-compass-rose", name:"New Trade Lane Discovered", scope:"Coastal kingdoms", impact:"Treasury +12, Repute opportunity", risk:"low" },
    { id:"assassin", icon:"ph-dagger", name:"Attempted Assassination", scope:"Single kingdom", impact:"Stability -14 if not addressed in same cycle", risk:"high" },
  ];
  const [selected, setSelected] = useState("famine");
  const [scope, setScope] = useState("imperium");
  const [delay, setDelay] = useState(0);
  const ev = events.find(e => e.id===selected);

  return (
    <div>
      <div className="gm-page-header">
        <div>
          <h1 className="gm-page-title">World Event Injector</h1>
          <div className="gm-page-sub">The professor turns the wheel of fortune. Choose with care.</div>
        </div>
        <GMBtn kind="ghost" icon="ph-clock-counter-clockwise"><span>Past Injections</span></GMBtn>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1.4fr 1fr",gap:16}}>
        <GMCard chrome={{icon:"ph-cards-three", label:"Event Library"}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            {events.map(e => (
              <button
                key={e.id}
                onClick={() => setSelected(e.id)}
                className={"gm-event-card " + (selected===e.id?"selected":"")}
              >
                <div className="gm-event-icon"><i className={"ph " + e.icon}></i></div>
                <div style={{textAlign:"left",flex:1}}>
                  <div style={{fontFamily:"var(--font-display)",fontSize:11.5,letterSpacing:".1em",textTransform:"uppercase",color:"var(--gold-2)"}}>{e.name}</div>
                  <div style={{fontFamily:"var(--font-italic)",fontStyle:"italic",fontSize:12,color:"var(--parchment-3)",marginTop:3}}>{e.scope}</div>
                </div>
                <span className={"gm-risk gm-risk-"+e.risk}>{e.risk==="high"?"high":e.risk==="med"?"med":"low"}</span>
              </button>
            ))}
          </div>
        </GMCard>

        <GMCard chrome={{icon:"ph-target", label:"Inject Parameters"}}>
          <div style={{display:"flex",alignItems:"center",gap:14,marginBottom:18}}>
            <div className="gm-event-icon" style={{width:48,height:48,fontSize:22}}><i className={"ph " + (ev?.icon||"ph-shooting-star")}></i></div>
            <div>
              <div style={{fontFamily:"var(--font-display)",fontSize:14,letterSpacing:".1em",textTransform:"uppercase",color:"var(--gold-2)"}}>{ev?.name}</div>
              <div style={{fontFamily:"var(--font-italic)",fontStyle:"italic",fontSize:13,color:"var(--parchment-3)",marginTop:2}}>{ev?.impact}</div>
            </div>
          </div>

          <div className="gm-balance-label" style={{marginBottom:8}}>Scope</div>
          <div style={{display:"flex",gap:6,marginBottom:18}}>
            {[
              {k:"single",l:"Single kingdom"},
              {k:"region",l:"Region"},
              {k:"imperium",l:"Imperium-wide"},
            ].map(o => (
              <button key={o.k} onClick={()=>setScope(o.k)} className={"gm-segment " + (scope===o.k?"active":"")}>{o.l}</button>
            ))}
          </div>

          <div className="gm-balance-label" style={{marginBottom:8}}>Affected sovereigns</div>
          <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:18}}>
            {KINGDOMS.slice(0, scope==="single"?6:scope==="region"?10:18).map(k => (
              <span key={k.name} className={"gm-token " + (scope==="single" && k.name!=="Vorant"?"ghost":"")}>{k.name}</span>
            ))}
          </div>

          <div className="gm-balance-row">
            <div className="gm-balance-label">Trigger at</div>
            <input type="range" min="0" max="3" defaultValue={delay} onChange={e=>setDelay(+e.target.value)} className="gm-balance-slider"/>
            <div className="gm-balance-value">+{delay} cycle{delay!==1?"s":""}</div>
          </div>
          <div className="gm-balance-row" style={{borderBottom:0}}>
            <div className="gm-balance-label">Visibility</div>
            <div style={{display:"flex",gap:6}}>
              <button className="gm-segment active">Sealed (anonymous)</button>
              <button className="gm-segment">Attributed</button>
            </div>
            <div></div>
          </div>

          <div style={{height:1,background:"rgba(168,128,74,.25)",margin:"14px 0"}}></div>

          <div style={{fontFamily:"var(--font-italic)",fontStyle:"italic",fontSize:13,color:"var(--parchment-3)",marginBottom:12,lineHeight:1.5}}>
            <i className="ph ph-warning" style={{color:"var(--oxblood-1)",marginRight:6}}></i>
            Once sealed, the event enters the world at the next cycle bell. The chancellery cannot retract a turning wheel.
          </div>

          <div style={{display:"flex",justifyContent:"flex-end",gap:8}}>
            <GMBtn kind="ghost">Cancel</GMBtn>
            <GMBtn kind="primary" icon="ph-stamp">Seal &amp; Inject</GMBtn>
          </div>
        </GMCard>
      </div>
    </div>
  );
};
window.EventInjector = EventInjector;
