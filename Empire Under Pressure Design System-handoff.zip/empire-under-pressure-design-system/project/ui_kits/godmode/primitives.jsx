/* eslint-disable */
// GOD-MODE shared primitives
const { useState, useEffect, useMemo } = React;

const GMCard = ({ chrome, children, style, padded = true }) => (
  <div className="gm-card" style={style}>
    {chrome && (
      <div className="gm-card-chrome">
        <span><i className={"ph " + (chrome.icon || "ph-book")} style={{marginRight:8}}></i>{chrome.label}</span>
        {chrome.right && <span className="gm-card-chrome-right">{chrome.right}</span>}
      </div>
    )}
    <div className="gm-card-body" style={padded ? null : { padding: 0 }}>{children}</div>
  </div>
);

const GMBtn = ({ kind = "primary", icon, children, onClick, size }) => (
  <button className={`gm-btn gm-btn-${kind}` + (size ? ` gm-btn-${size}` : "")} onClick={onClick}>
    {icon && <i className={"ph " + icon}></i>}
    {children}
  </button>
);

const GMStat = ({ label, value, delta, deltaTone }) => (
  <div className="gm-stat">
    <div className="gm-stat-label">{label}</div>
    <div className="gm-stat-value">{value}</div>
    {delta && <div className={`gm-stat-delta ${deltaTone || (String(delta).startsWith("-") ? "down" : "up")}`}>{delta}</div>}
  </div>
);

// 18 kingdoms — fictitious houses, varied tones, plausible student names
const KINGDOMS = [
  { name: "Calidone", student: "A. Mendez", state: "ok",     stab: 78, leg: 71, tre: 62, mil: 44, edicts: 4, last: "12m" },
  { name: "Vorant",   student: "R. Okafor", state: "danger", stab: 31, leg: 42, tre: 88, mil: 71, edicts: 2, last: "3h"  },
  { name: "Halberd",  student: "J. Lin",    state: "warn",   stab: 54, leg: 48, tre: 51, mil: 67, edicts: 3, last: "44m" },
  { name: "Marivell", student: "S. Patel",  state: "ok",     stab: 82, leg: 76, tre: 54, mil: 38, edicts: 5, last: "18m" },
  { name: "Drasimor", student: "K. Schultz",state: "warn",   stab: 49, leg: 60, tre: 33, mil: 58, edicts: 2, last: "2h"  },
  { name: "Eldwyn",   student: "T. Iqbal",  state: "ok",     stab: 71, leg: 80, tre: 58, mil: 41, edicts: 4, last: "9m"  },
  { name: "Nessor",   student: "P. Dubois", state: "danger", stab: 24, leg: 38, tre: 21, mil: 64, edicts: 1, last: "6h"  },
  { name: "Kornholt", student: "M. Costa",  state: "ok",     stab: 66, leg: 64, tre: 71, mil: 52, edicts: 3, last: "21m" },
  { name: "Strathvale",student:"L. Park",   state: "ok",     stab: 73, leg: 68, tre: 49, mil: 47, edicts: 4, last: "31m" },
  { name: "Aldemar",  student: "F. Rossi",  state: "warn",   stab: 52, leg: 55, tre: 41, mil: 60, edicts: 2, last: "1h"  },
  { name: "Brynholm", student: "C. Devlin", state: "ok",     stab: 69, leg: 72, tre: 56, mil: 50, edicts: 4, last: "14m" },
  { name: "Vesper",   student: "N. Achebe", state: "ok",     stab: 75, leg: 79, tre: 60, mil: 39, edicts: 5, last: "8m"  },
  { name: "Carthen",  student: "B. Yamada", state: "warn",   stab: 47, leg: 51, tre: 64, mil: 70, edicts: 3, last: "55m" },
  { name: "Ostvar",   student: "E. Larsen", state: "ok",     stab: 64, leg: 66, tre: 53, mil: 48, edicts: 3, last: "28m" },
  { name: "Pelmark",  student: "Z. Reyes",  state: "danger", stab: 28, leg: 34, tre: 18, mil: 42, edicts: 0, last: "1d"  },
  { name: "Thornwich",student: "G. Abara",  state: "ok",     stab: 70, leg: 73, tre: 57, mil: 44, edicts: 4, last: "23m" },
  { name: "Idreth",   student: "H. Kobayashi",state:"warn",  stab: 51, leg: 57, tre: 46, mil: 63, edicts: 2, last: "1h"  },
  { name: "Sornland", student: "I. Martín", state: "ok",     stab: 68, leg: 70, tre: 59, mil: 45, edicts: 4, last: "16m" },
];

Object.assign(window, { GMCard, GMBtn, GMStat, KINGDOMS });
