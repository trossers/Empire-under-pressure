/* eslint-disable */
const Overview = () => {
  const counts = KINGDOMS.reduce((a,k)=>{a[k.state]=(a[k.state]||0)+1;return a;},{});
  return (
    <div>
      <div className="gm-page-header">
        <div>
          <h1 className="gm-page-title">The Realm at Cycle XII</h1>
          <div className="gm-page-sub">Eighteen sovereigns. Three in distress. The world holds.</div>
        </div>
        <div style={{display:"flex", gap:12}}>
          <GMBtn kind="secondary" icon="ph-pause"><span>Pause World</span></GMBtn>
          <GMBtn kind="primary" icon="ph-fast-forward"><span>Advance Cycle</span></GMBtn>
        </div>
      </div>

      <div style={{display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:14, marginBottom:24}}>
        <GMStat label="Sovereigns Active" value="18" delta="+0 this cycle" />
        <GMStat label="Stable" value={counts.ok || 0} delta={`${Math.round(((counts.ok||0)/18)*100)}% of realm`} />
        <GMStat label="Wavering" value={counts.warn || 0} delta="+1 since last cycle" deltaTone="up" />
        <GMStat label="In Crisis" value={counts.danger || 0} delta="+2 since last cycle" deltaTone="down" />
        <GMStat label="Pending Edicts" value={KINGDOMS.reduce((a,k)=>a+k.edicts,0)} delta="awaiting seal" />
      </div>

      <GMCard chrome={{icon:"ph-globe-hemisphere-west", label:"Eighteen Kingdoms · Live", right:<span style={{fontFamily:"var(--font-mono)",fontSize:11}}>auto-refresh 30s</span>}}>
        <div className="gm-kingdom-grid">
          {KINGDOMS.map(k => (
            <div key={k.name} className={"gm-tile " + (k.state==="danger"?"danger":k.state==="warn"?"warn":"")}>
              <div className="gm-tile-status"></div>
              <div className="gm-tile-name">{k.name}</div>
              <div className="gm-tile-student">{k.student}</div>
              <div className="gm-tile-bars" title="stability · legitimacy · treasury · militia">
                <span><i className={k.stab<35?"lo":k.stab<60?"mid":""} style={{width:k.stab+"%"}}></i></span>
                <span><i className={k.leg<35?"lo":k.leg<60?"mid":""} style={{width:k.leg+"%"}}></i></span>
                <span><i className={k.tre<35?"lo":k.tre<60?"mid":""} style={{width:k.tre+"%"}}></i></span>
                <span><i className={k.mil<35?"lo":k.mil<60?"mid":""} style={{width:k.mil+"%"}}></i></span>
              </div>
              <div className="gm-tile-stats">
                <span>{k.edicts} edicts</span>
                <span>· {k.last} ago</span>
              </div>
            </div>
          ))}
        </div>
      </GMCard>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16, marginTop:16}}>
        <GMCard chrome={{icon:"ph-warning", label:"Most Recent Crises"}}>
          <div className="gm-alert-row">
            <div className="gm-alert-icon"><i className="ph ph-flame"></i></div>
            <div>
              <div className="gm-alert-text"><strong style={{color:"var(--gold-2)"}}>Pelmark</strong> — bread riots in the capital. Stability at 28; treasury exhausted.</div>
              <div className="gm-alert-meta">Z. Reyes · 1d 02h since last edict · auto-flagged at 14:08</div>
            </div>
            <span className="gm-grade-pill" style={{background:"rgba(122,31,35,.18)",color:"#e8a7a9",borderColor:"rgba(122,31,35,.4)"}}>Critical</span>
            <GMBtn kind="ghost" icon="ph-arrow-up-right"><span>Inspect</span></GMBtn>
          </div>
          <div className="gm-alert-row">
            <div className="gm-alert-icon"><i className="ph ph-sword"></i></div>
            <div>
              <div className="gm-alert-text"><strong style={{color:"var(--gold-2)"}}>Vorant</strong> withdrew its emissary from <strong style={{color:"var(--gold-2)"}}>Halberd</strong>. War footing rising.</div>
              <div className="gm-alert-meta">R. Okafor · 3h ago · militia +14 in three cycles</div>
            </div>
            <span className="gm-grade-pill" style={{background:"rgba(122,31,35,.18)",color:"#e8a7a9",borderColor:"rgba(122,31,35,.4)"}}>Critical</span>
            <GMBtn kind="ghost" icon="ph-arrow-up-right"><span>Inspect</span></GMBtn>
          </div>
          <div className="gm-alert-row">
            <div className="gm-alert-icon warn"><i className="ph ph-currency-circle-dollar"></i></div>
            <div>
              <div className="gm-alert-text"><strong style={{color:"var(--gold-2)"}}>Nessor</strong> — coffers below famine threshold for the third consecutive cycle.</div>
              <div className="gm-alert-meta">P. Dubois · 6h ago</div>
            </div>
            <span className="gm-grade-pill" style={{background:"rgba(168,128,74,.18)"}}>Warn</span>
            <GMBtn kind="ghost" icon="ph-arrow-up-right"><span>Inspect</span></GMBtn>
          </div>
        </GMCard>

        <GMCard chrome={{icon:"ph-sliders-horizontal", label:"World Balance Controls"}}>
          {[
            { l:"Harvest Yield", v:"1.00 ×", pct:50 },
            { l:"Trade Friction", v:"0.85 ×", pct:35 },
            { l:"Plague Pressure", v:"0.10 ×", pct:10 },
            { l:"Crown Tax Cap", v:"22 %", pct:55 },
            { l:"Diplomacy Decay", v:"0.4 / cycle", pct:40 },
          ].map(b => (
            <div className="gm-balance-row" key={b.l}>
              <div className="gm-balance-label">{b.l}</div>
              <input type="range" className="gm-balance-slider" defaultValue={b.pct}/>
              <div className="gm-balance-value">{b.v}</div>
            </div>
          ))}
          <div style={{display:"flex",justifyContent:"flex-end",gap:8,marginTop:12}}>
            <GMBtn kind="ghost">Restore Defaults</GMBtn>
            <GMBtn kind="primary" icon="ph-check">Apply Next Cycle</GMBtn>
          </div>
        </GMCard>
      </div>
    </div>
  );
};
window.Overview = Overview;
