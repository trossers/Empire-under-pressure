/* eslint-disable */
const AlertCenter = () => {
  const alerts = [
    { tone:"danger", icon:"ph-flame", title:"Pelmark — open insurrection", meta:"Z. Reyes · 1d 02h", body:"Bread riots in the capital. Stability 28, legitimacy 34, treasury exhausted. The student has not logged in for 26 hours." },
    { tone:"danger", icon:"ph-sword", title:"Vorant ↔ Halberd — war footing", meta:"R. Okafor · 3h", body:"Vorant withdrew its emissary. Militia spending +14 over three cycles. Halberd has issued a counter-mobilization edict." },
    { tone:"warn", icon:"ph-currency-circle-dollar", title:"Nessor — famine threshold breached", meta:"P. Dubois · 6h", body:"Coffers below famine threshold for the third consecutive cycle. No grain levy issued." },
    { tone:"warn", icon:"ph-handshake", title:"Drasimor — broken concord", meta:"K. Schultz · 2h", body:"Treaty of the Three Rivers terminated unilaterally. Repute -8 across the imperium." },
    { tone:"info", icon:"ph-clock-counter-clockwise", title:"Aldemar — disengaged", meta:"F. Rossi · last seen 1d 9h", body:"No edicts issued in two cycles. Suggest dispatch from the chancellery." },
    { tone:"info", icon:"ph-feather", title:"Six essays past due", meta:"Cycle XI submission window", body:"Vorant, Nessor, Pelmark, Carthen, Aldemar, Idreth have not submitted their cycle reflections." },
    { tone:"warn", icon:"ph-scales", title:"Carthen — legitimacy in decline", meta:"B. Yamada · 55m", body:"Three consecutive ceremonial edicts ignored by clergy. Repute -3." },
    { tone:"info", icon:"ph-eye", title:"S.A.S.S.Y. summoned 41 times", meta:"this cycle · all sovereigns", body:"Highest summon volume: Pelmark (12), Nessor (9), Vorant (7). Lowest: Eldwyn (0)." },
  ];
  return (
    <div>
      <div className="gm-page-header">
        <div>
          <h1 className="gm-page-title">Dispatch Center</h1>
          <div className="gm-page-sub">Eight matters await professorial attention.</div>
        </div>
        <div style={{display:"flex", gap:8}}>
          <GMBtn kind="ghost" icon="ph-funnel"><span>Filter</span></GMBtn>
          <GMBtn kind="secondary" icon="ph-archive"><span>Archive Resolved</span></GMBtn>
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:16}}>
        <GMCard chrome={{icon:"ph-warning", label:"Active Dispatches"}}>
          {alerts.map((a,i) => (
            <div className="gm-alert-row" key={i}>
              <div className={"gm-alert-icon " + (a.tone==="warn"?"warn":a.tone==="info"?"info":"")}>
                <i className={"ph " + a.icon}></i>
              </div>
              <div>
                <div className="gm-alert-text"><strong style={{color:"var(--gold-2)"}}>{a.title}</strong></div>
                <div style={{fontFamily:"var(--font-serif)",fontSize:13,color:"var(--parchment-2)",marginTop:3,lineHeight:1.5,fontStyle:"italic"}}>{a.body}</div>
                <div className="gm-alert-meta" style={{marginTop:4}}>{a.meta}</div>
              </div>
              <span className="gm-grade-pill" style={a.tone==="danger"?{background:"rgba(122,31,35,.18)",color:"#e8a7a9",borderColor:"rgba(122,31,35,.4)"}:a.tone==="warn"?{background:"rgba(168,128,74,.18)"}:{background:"rgba(28,42,58,.4)",color:"#a9c4dd",borderColor:"rgba(58,82,114,.5)"}}>
                {a.tone === "danger" ? "Critical" : a.tone === "warn" ? "Warn" : "Notice"}
              </span>
              <div style={{display:"flex",gap:6}}>
                <GMBtn kind="ghost" icon="ph-arrow-up-right"><span>Inspect</span></GMBtn>
                <GMBtn kind="secondary" icon="ph-check"><span>Resolve</span></GMBtn>
              </div>
            </div>
          ))}
        </GMCard>

        <GMCard chrome={{icon:"ph-paper-plane-tilt", label:"Compose Dispatch"}}>
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <label className="gm-balance-label">Recipient</label>
            <select style={{width:"100%",background:"#100706",color:"var(--gold-2)",border:"1px solid rgba(168,128,74,.3)",padding:"8px 10px",fontFamily:"var(--font-serif)",fontSize:14,borderRadius:2}}>
              <option>All sovereigns</option>
              <option>Pelmark · Z. Reyes</option>
              <option>Vorant · R. Okafor</option>
              <option>Nessor · P. Dubois</option>
            </select>
            <label className="gm-balance-label">Subject</label>
            <input defaultValue="On the matter of the cycle's submissions" style={{width:"100%",background:"#100706",color:"var(--parchment-1)",border:"1px solid rgba(168,128,74,.3)",padding:"8px 10px",fontFamily:"var(--font-serif)",fontSize:14,borderRadius:2}}/>
            <label className="gm-balance-label">Communiqué</label>
            <textarea rows={6} defaultValue={"Sovereigns,\n\nThe chancellery observes that several of you have not yet sealed your reflections for Cycle XI. The window closes at the next bell. As ever, the imperium watches its scribes more closely than its generals."} style={{width:"100%",background:"#100706",color:"var(--parchment-1)",border:"1px solid rgba(168,128,74,.3)",padding:"10px 12px",fontFamily:"var(--font-serif)",fontSize:14,lineHeight:1.55,borderRadius:2,resize:"vertical"}}/>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <label style={{fontFamily:"var(--font-serif)",fontSize:13,color:"var(--parchment-3)",fontStyle:"italic"}}><input type="checkbox" defaultChecked/> sign as professor (visible)</label>
              <GMBtn kind="primary" icon="ph-paper-plane-tilt">Dispatch</GMBtn>
            </div>
          </div>
        </GMCard>
      </div>
    </div>
  );
};
window.AlertCenter = AlertCenter;
