# GOD-MODE — Professor Admin Panel UI Kit

The professor's command surface. Visual register: the same imperial language as the simulator, but darker — chrome-dominant, bloomberg-meets-archive. The professor sees what students cannot.

## Files
- `index.html` — overview dashboard with switcher
- `godmode.css` — admin-specific styles (extends empire.css patterns, adds dark canvas + data-density)
- `Overview.jsx` — all 18 kingdoms at a glance
- `AlertCenter.jsx` — instability, dangerous relations, disengaged students
- `EssayQueue.jsx` — pending essays with grading lane
- `Roster.jsx` — student engagement
- `EventInjector.jsx` — world-event injector

## Pattern notes
- The page background is darker (umber-1) — the professor works "behind the curtain"
- Density is higher; serif body sits at 13–14px
- Primary accent shifts from oxblood to gold — the professor *gilts* the world
- Audit log is omnipresent (footer ribbon)
