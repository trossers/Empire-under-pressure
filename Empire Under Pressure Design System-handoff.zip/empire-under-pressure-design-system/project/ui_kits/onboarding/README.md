# Onboarding — Found Your Kingdom

Five-step founding flow that runs once per student per term. Output of the flow becomes the realm's permanent metadata — name, house, motto, doctrine, crest, counsel tone.

## Files
- `index.html` — full React flow (5 steps + ceremony)
- `onboarding.css` — page styles, choice cards, crest stage, ceremony seal

## Steps
1. **Doctrine** — six starting constitutions. Each carries a different stat profile and a different essay prompt the professor will assign at Cycle II.
2. **Realm** — name, house, motto. Live-rendered as a forthcoming charter.
3. **Crest** — six tinctures × sixteen charges. The shield renders the chosen state on the same surface as the Treasury seal.
4. **Counsel** — three tones for S.A.S.S.Y.: plain, ironic, ceremonial. Each shows a sample line so the choice is informed.
5. **Founding** — the seal stamps. S.A.S.S.Y. delivers her first dispatch. CTA enters the simulator.

## Pattern notes
- No "skip" affordance. The founding is ceremonial — students must walk through it.
- Back navigation is allowed at every step except Doctrine.
- The seal-stamp ceremony reuses the same `eup-stamp`/`ob-stamp` keyframes as the turn-end ritual; the visual language of *committing the seal* is consistent across the system.
- Student name and class roster are assumed to be passed in by the LMS / professor account; this flow is realm-only.
