# Empire Under Pressure — Design System

> *Imperial academia. Vatican archive meets Oxford common room. Parchment, oxblood, gold leaf, deep navy.*

---

## Product context

**Empire Under Pressure** is an educational simulation platform for geopolitics and political philosophy. Students found and govern kingdoms inside a shared imperial world, take strategic decisions, and live with the academic, diplomatic, and military consequences of their ideas. A professor administers the world via **GOD-MODE**.

Three distinct surfaces — visually unified, functionally separated:

| Surface | Audience | Purpose |
|---|---|---|
| **Empire Under Pressure** | Students (up to 18 simultaneous) | The simulator itself. Kingdom dashboard, edicts, diplomacy, treasury, war, essays. |
| **S.A.S.S.Y.** | Students | Internal AI counselor. Intelligent, ironic, elegant, slightly manipulative. *Never* caricaturish. Speaks in italic serif, lives on a vellum card. |
| **GOD-MODE** | Professor / admin only | Overview of all kingdoms, alerts, balance controls, audit log, world-event injector, essay queue. |

### Source materials
No codebase, Figma, or visual references were attached. This design system was authored from the written brief alone. **Substitution flag**: all fonts are loaded from Google Fonts (Cinzel, Spectral, JetBrains Mono); icons are referenced from Phosphor via CDN. If you have proprietary marks, illustrations, or webfont licenses, attach them and I will swap them in.

---

## Index

```
README.md                  ← you are here
SKILL.md                   ← agent-skill manifest (cross-compatible w/ Claude Code)
colors_and_type.css        ← all design tokens + semantic type classes
fonts/                     ← (Google Fonts loaded via @import; no local files yet)
assets/
  logo-mark.svg            ← imperial seal mark
  logo-wordmark.svg        ← Cinzel wordmark
  logo-lockup.svg          ← combined
  ornament-rule.svg        ← decorative double-rule with center medallion
  ornament-corner.svg      ← corner flourish
preview/                   ← Design System tab cards (Type / Colors / Spacing / Components / Brand)
ui_kits/
  empire/                  ← student simulator (dashboard, edict, diplomacy, war, treasury, turn-end)
  godmode/                 ← professor panel (overview, alerts, essay queue, roster, event injector)
  sassy/                   ← AI counselor surfaces (chat card, summon, full conversation)
  onboarding/              ← "Found Your Kingdom" flow
```

Open `preview/` files individually, or browse the **Design System** tab to review every registered card.

---

## Content fundamentals

**Voice.** Formal imperial. Ceremonial English. The product addresses the player as *Your Majesty* or by their title (*Sovereign of [Kingdom]*). Third-person address for actions taken on behalf of the Crown. Dispatches, edicts, communiqués — never "messages" or "notifications."

**Casing.** Display type is **uppercase Cinzel** with generous letter-spacing — used for screen titles, primary nav, kingdom names. Body sets sentence case in Spectral. Numbers and resource readouts in JetBrains Mono. No Title Case On Mid-Length Headers; reserve uppercase for the display family.

**Vocabulary.** A controlled register. Use:

| Use | Don't use |
|---|---|
| Edict, decree, proclamation | Action, command |
| Dispatch, communiqué, missive | Notification, message, ping |
| Treasury, coffers, levies | Wallet, balance, tax |
| Court, council, chancellery | Settings, admin, dashboard |
| Treaty, accord, concord | Agreement, deal |
| Stability, legitimacy, repute | Health, score, rating |
| Turn → **Reign** or **Cycle** | Round, level |
| The realm, the imperium | The world, the game |

**S.A.S.S.Y. voice example** (italic Spectral, on vellum):

> *Your Majesty inherits a fragile peace. The Duchy of Vorant has not forgotten the bread riots — and yet, neither have your bakers. A subsidy now is generosity; a subsidy after the next harvest is desperation. I leave the choice, naturally, to your better judgment.*

Note the cadence: long sentences, em-dashes, an aside in italics-within-italics, ending with a polite undermining ("naturally"). S.A.S.S.Y. is never sycophantic, never warns in capital letters, never uses emoji.

**Tone for system messages.**
- Confirmations are *acknowledgements*: "The decree is sealed."
- Errors are *impediments*: "The Crown lacks sufficient grain to honor this levy."
- Loading states are *ceremonies*: "The chancellery prepares the dispatch…"

**No emoji. Ever.** Not in copy, not in UI. Use Phosphor icons or unicode dingbats (✦ ✧ † ‡ § ⁂) for ornament.

**Sample copy** (correct register):

- *Found Your Kingdom* — onboarding CTA
- *The Realm at Cycle XII* — dashboard heading
- *Three matters await your seal* — pending-decisions banner
- *Vorant has withdrawn its emissary.* — diplomacy alert
- *S.A.S.S.Y. requests audience.* — advisor summon
- *The professor has invoked GOD-MODE.* — admin notice (visible to students when the world is paused)

---

## Visual foundations

### Palette
A four-anchor system: **parchment** (surfaces), **ink** (text), **oxblood** (primary accent / danger / seals), **navy** (links / diplomacy / info), with **gold** (decorative, never structural) and **moss** (success, treaties signed). See `colors_and_type.css` for the full token set.

- Backgrounds default to `--parchment-1` (#f4ecd8) — never pure white.
- Chrome (top bars, sidebars, modals' frames) uses `--umber-1` (#3a1f1a) — a deep imperial brown that reads as carved oak under candlelight.
- Oxblood is the **only** color that triggers strong emotional weight: war declarations, instability spikes, GOD-MODE alerts, the imperial seal. Use sparingly.

### Type
- **Display:** Cinzel 500/600 — uppercase, monumental, generous tracking (0.04–0.05em).
- **Body:** Spectral 400/500 — a transitional serif with calligraphic weight in italics.
- **Italic:** Spectral italic — reserved for S.A.S.S.Y., quotations, and ship names / treaty names.
- **Mono:** JetBrains Mono 400/500 — used for numeric data (resources, dates, coordinates), audit log entries, kingdom IDs.

Never set body copy in Cinzel. Never use Cinzel below 14px. Mixing display-uppercase with mono-uppercase creates the Bloomberg-meets-archive feel — leverage it.

### Spacing
4-step scale (4 / 8 / 12 / 16 / 24 / 32 / 48 / 64 / 96). Card interior padding is generous — 24–32px — to let serif type breathe. Line-height for body Spectral runs 1.55–1.65.

### Backgrounds & textures
- The default page is `bg-parchment` — a flat parchment color with two faint radial highlights (gold top-left, oxblood bottom-right) and an extremely subtle 1px crosshatch (~1% opacity). Reads as paper, never as "texture overlay."
- S.A.S.S.Y. cards use `bg-vellum` — slightly warmer parchment.
- Full-bleed imagery (when present) should be desaturated, warm-toned, oil-painting palette. A subtle 4% film grain is appropriate; sharp digital photography is not.
- **Never** use bluish-purple gradients, soft drop-shadow stacks, or glassmorphism. **Never** use repeating decorative patterns as page backgrounds — that's the medieval RPG cliché we are escaping.

### Borders
- Hairline: 1px `--border-1` — used between rows in dense tables.
- Standard: 1px `--border-2` — card borders.
- Strong: 1px `--border-3` — modal & sidebar separators.
- Decorative: a 2px gold double-rule (`rule-double-gold`) — used **only** at section boundaries on long pages, never inside cards.

### Elevation / shadows
Letterpress, not levitation. Cards rest on the page with a 1-px ink shadow at the bottom edge (`--shadow-1`) — it reads as the card *pressing into* the parchment, not floating above it. Modals use `--shadow-3` (a soft, ink-toned drop shadow with no blur halo). Inputs use `--shadow-sunken` (an inset 1px ink line on top + a 1px highlight on bottom — the field is *cut into* the page).

The imperial seal (oxblood circle on logo, primary CTA on critical screens) uses `--shadow-seal` — a faint oxblood haze.

### Corner radii
**Restrained.** Imperial doesn't bubble.
- Cards & modals: 4px (`--radius-2`)
- Inputs: 2–4px
- Buttons: 4px
- Pills (resource counters, status chips): full pill (`--radius-pill`)
- Imperial seal / GOD-MODE primary: full circle

No 16–24px "soft" radii anywhere.

### Cards
Card = parchment-2 surface, 1px border-2, 4px radius, shadow-1. No gradients on card interiors. Card titles use the `.h2` or `.h3` class with a thin gold rule beneath. Action chrome (close button, more-actions) sits on the umber chrome strip across the top of major cards; minor cards have no chrome.

### Hover states
- Buttons darken (`--accent-hover` for primary, ~6% darker for secondary)
- Links shift from navy to oxblood on hover (a *meaningful* shift — the user is being warned the link will commit them)
- Card rows pick up a 1px parchment-3 background — never a shadow-bloom

### Press states
- Buttons darken further to `--accent-pressed` and pick up the inset shadow-sunken (the button "presses into" the page)
- No scale transforms. Imperial UI does not bounce.

### Animation
- Default easing: `--ease-imperial` (`cubic-bezier(0.32, 0.08, 0.24, 1)`) — slow-in, slow-out. Ceremonial.
- Durations: 120ms (micro), 200ms (standard), 360ms (panel slides), 720ms (turn-advance ceremony, seal stamp).
- Fades preferred over slides. Scale transforms reserved for the seal-stamp animation on edicts (a 1.0 → 1.04 → 1.0 rubber-stamp ceremony).
- No bounces, no springy overshoot, no parallax. The world moves with the deliberate pace of court protocol.

### Transparency & blur
Used sparingly. The only blur in the system is on the modal scrim — `backdrop-filter: blur(2px)` over a 55% ink overlay. Glass panels, frosted sidebars, and translucent cards are not part of the language.

### Layout rules
- Top chrome (umber bar, 56px) — fixed. Carries the imperial wordmark, current cycle indicator, S.A.S.S.Y. summon, the player's own crest.
- Left chrome (umber rail, 64px or 220px expanded) — fixed. Primary nav.
- Main canvas — scrolls.
- A page is composed of cards on parchment, separated by 24–32px gutters and (rarely) a gold double-rule for major sections.
- 12-column grid at 1280–1920; 8-column at 768–1280.
- Minimum tap target 44×44 (decorative gilt cannot reduce this).

### Imagery vibe
Warm, desaturated, oil-painting palette. Renaissance portraits, parchment maps, brass instruments, candle-lit chambers. **Never** photo-realistic stock, **never** flat illustration with bright primary colors, **never** isometric "tech" art. When in doubt, leave a placeholder — see ICONOGRAPHY.

---

## Iconography

**System:** Phosphor Icons (regular weight, 1.5px stroke) loaded from CDN.
- CDN: `https://unpkg.com/@phosphor-icons/web@2.1.1/src/regular/style.css`
- Usage: `<i class="ph ph-crown"></i>`
- Stroke weight is `regular` everywhere except primary CTA buttons (which use `bold`) and decorative ornaments (which use `duotone` with the gold + ink palette).

**Why Phosphor.** Geometric, slightly editorial, regular weight reads at home next to Spectral body type. Lucide is too utilitarian for an imperial register; Heroicons too rounded.

**Icon sizes.**
- 16px — inline with body text
- 20px — toolbar / nav (default)
- 24px — primary actions, card headers
- 32px — empty states / hero accents
- 48px+ — decorative only

**Decorative ornaments.** For section dividers and seal-style accents we use unicode dingbats (✦ ✧ † ‡ § ⁂ ❦) and an SVG ornament rule (`assets/ornament-rule.svg`). These are *not* icons; they are typographic ornament and should be set in the gold-3 hue, never in oxblood.

**Brand mark.** The imperial seal — a stylized crown over a laurel ring with the wordmark *EMPIRE UNDER PRESSURE* — is in `assets/logo-mark.svg` (mark only), `assets/logo-wordmark.svg` (wordmark only), and `assets/logo-lockup.svg` (combined). A circular oxblood seal version exists for "stamp" moments (`assets/seal-circle.svg`).

**Emoji.** Forbidden in all surfaces.

**Substitution flag.** Phosphor is a substitution; if you have a proprietary icon set or wish to use a heraldic illustration set for kingdom crests, attach it and I will swap.

---

## Caveats

- **No source materials provided.** Everything visual was authored from the written brief. The brand mark, ornaments, and color anchors are educated proposals — not derived from existing artwork. They will need your sign-off.
- **Fonts are Google Fonts substitutes.** Cinzel + Spectral + JetBrains Mono are the closest free matches to the imperial-academia direction. If you license commercial faces (Trajan Pro for display, Adobe Garamond Premier for body, Berkeley Mono for data), I can swap.
- **Iconography is Phosphor via CDN.** A proper imperial UI would benefit from a small custom set of heraldic glyphs (crown, sword, scroll, scale, anchor, hourglass) drawn in the same hand as the brand mark. Flagged for follow-up.
- **18-player concurrency, audit logs, and Apps-Script→Supabase migration paths** are product concerns, not visual ones — but the UI affordances for those (alert center, log timeline, world-event injector) are mocked in the GOD-MODE kit.
